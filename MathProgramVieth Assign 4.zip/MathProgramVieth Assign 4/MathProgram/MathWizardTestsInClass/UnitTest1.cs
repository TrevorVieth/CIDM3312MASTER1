using System;
using Xunit;

using MathWizard.Controllers;
using MathWizard.Models;

namespace MathWizardTestsInClass
{
    public class UnitTest1
    {

        MathController controller = new MathController();

        [Fact]
        public void Test1()
        {
            //Arrange

            //Act

            //Assert
            

        }
    }
}
